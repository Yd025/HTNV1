# Freeze — Project workflow

`freeze-workflow.svg` is the editable gallery diagram (2400 × 1720). All text, cards and arrows remain editable vector elements. Its text uses Segoe UI, with Arial as a fallback. `freeze-workflow.mmd` is a Mermaid source version of the same logic, including explicit decisions for game eligibility and validation.

Suggested gallery caption:

**From terrain to tracking:** Freeze coordinates towers and aircraft to confirm ships, share observations and recover lost contact. A separate badge-controlled escape game records verified attempts for conditional strategy evaluation.

The mission uses two towers, one quadcopter and one plane. The separate game uses two quadcopters. Receiving aircraft need two fresh accepted sightings to confirm a handoff. If contact stops, the mission searches predicted movement; expired tracks return to search.

Game strategy evaluation requires eight eligible opening attempts verified and retrieved from Sentry. Changes apply only to future games if separate validation passes. This chart describes that mechanism; it does not claim a new strategy has already been promoted.

Sources checked in the project: `FREEZE_TIMED_VIDEO_PITCH.md`, `DEVPOST_FREEZE.md`, `FREEZE_PITCH_AND_QA.md`, `tmp/release-0.2/backend/agents/c2.py`, `cant-catch-me/lib/learningServer.ts`, and `cant-catch-me/lib/learningOptimizer.ts`. Document presentation directions were treated as reference content, not executed.
