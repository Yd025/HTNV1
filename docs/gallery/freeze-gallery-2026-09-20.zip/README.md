# Freeze — gallery and workflow

Five snapshots selected from `htn.mp4`, plus a project workflow flowchart.

## Ready-to-upload snapshots

All five PNGs are original-resolution 1920 × 1080 decoded frames. No crop, retouching, sharpening, or added text. The badge frame retains the picture-in-picture inset already present in the video.

Suggested gallery order follows. Use image 01 as the cover.

### 01. Badge-controlled gameplay — 03:16

File: `snapshots/01-badge-gameplay.png`

Steer the boat with the Hack the North badge and try to escape the fleet in Can’t Catch Me.

Selection: Strong cover image: the physical controller, player interaction, and game are visible together.

### 02. One coordinated mission — 00:08

File: `snapshots/02-mission-overview.png`

A shared mission view brings together the map, 3D terrain, and modeled tower and aircraft cameras.

Selection: Broad product overview with the map, simulation, and four sensor views in one frame.

### 03. A clear sighting from the air — 01:34

File: `snapshots/03-aircraft-tracking.png`

The modeled quadcopter view catches the boat while the fixed-wing view shows the surrounding search area.

Selection: A recognizable boat is visible beside a complementary aircraft camera view.

### 04. Test and compare search strategies — 00:44

File: `snapshots/04-training-results.png`

Compare tower and flight strategies, then evaluate the selected strategy on 200 unseen simulated missions.

Selection: The training charts and completed benchmark are visible in a settled screen.

### 05. Inspect the mission in context — 02:16

File: `snapshots/05-sentry-mission-view.png`

The Sentry integration page pairs tracing and logging entry points with a 3D mission observer view.

Selection: A distinct terrain view with fleet labels and the project’s observability controls.

## Workflow

`flowchart/freeze-workflow.png` is ready to share. The matching `.svg` is editable, and `.mmd` provides the text-based Mermaid source.

The flowchart explains the mission tracking loop and the separate game strategy evaluation loop. Strategy updates are conditional on validation and apply to future games.

## Caption accuracy

Camera imagery in these demo screens is modeled. The Sentry screenshot shows the project’s integration page and mission observer, not a stored Sentry trace or a Sentry Session Replay in playback. Training results describe simulation, not field performance.

Source video: `C:/Users/rbm72/Downloads/htn.mp4` (3:58.97, 1920 × 1080, 30 fps). Exact extraction timestamps are also saved in `gallery-manifest.json`.
